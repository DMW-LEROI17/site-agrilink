// AGRICAM - COUCHE API
const API_URL = 'http://localhost:3000/api';
const getToken = () => localStorage.getItem('agricam_token');
const apiHeaders = (a) => { const h={'Content-Type':'application/json'}; if(a){const t=getToken();if(t)h['Authorization']='Bearer '+t;} return h; };
const apiCall = async (method,endpoint,data,auth) => {
  if(auth===undefined)auth=true;
  try {
    const opts={method,headers:apiHeaders(auth)};
    if(data&&method!=='GET')opts.body=JSON.stringify(data);
    const r=await fetch(API_URL+endpoint,opts);
    const j=await r.json();
    if(!r.ok)throw new Error(j.message||'Erreur');
    return j;
  } catch(e){console.error('API:',e);throw e;}
};
const Auth={
  async inscription(d){const r=await apiCall('POST','/auth/inscription',d,false);if(r.token){localStorage.setItem('agricam_token',r.token);localStorage.setItem('agricam_user',JSON.stringify(r.user));}return r;},
  async connexion(tel,pw){const r=await apiCall('POST','/auth/connexion',{telephone:tel,password:pw},false);if(r.token){localStorage.setItem('agricam_token',r.token);localStorage.setItem('agricam_user',JSON.stringify(r.user));}return r;},
  deconnexion(){localStorage.removeItem('agricam_token');localStorage.removeItem('agricam_user');window.location.reload();},
  estConnecte:()=>!!getToken(),
  utilisateur:()=>JSON.parse(localStorage.getItem('agricam_user')||'null')
};
const Produits={
  lister:(p)=>apiCall('GET','/produits?'+new URLSearchParams(p||{}).toString(),null,false),
  detail:(id)=>apiCall('GET','/produits/'+id,null,false),
  creer:(d)=>apiCall('POST','/produits',d),
  modifier:(id,d)=>apiCall('PUT','/produits/'+id,d),
  supprimer:(id)=>apiCall('DELETE','/produits/'+id)
};
const Commandes={
  passer:(d)=>apiCall('POST','/commandes',d),
  mesCommandes:()=>apiCall('GET','/commandes/mes-commandes'),
  mesVentes:()=>apiCall('GET','/commandes/mes-ventes'),
  changerStatut:(id,s,c)=>apiCall('PUT','/commandes/'+id+'/statut',{statut:s,codeConfirmation:c})
};
const Paiements={
  initierMTN:(cId,tel,mt)=>apiCall('POST','/paiements/mtn-momo/initier',{commandeId:cId,telephone:tel,montant:mt}),
  initierOrange:(cId,tel,mt)=>apiCall('POST','/paiements/orange-money/initier',{commandeId:cId,telephone:tel,montant:mt}),
  verifierStatut:(cId)=>apiCall('GET','/paiements/statut/'+cId)
};
const Entreprises={
  lister:(p)=>apiCall('GET','/entreprises?'+new URLSearchParams(p||{}).toString(),null,false),
  detail:(id)=>apiCall('GET','/entreprises/'+id,null,false),
  creer:(d)=>apiCall('POST','/entreprises',d),
  valider:(id)=>apiCall('PUT','/entreprises/'+id+'/valider',{})
};
const Projets={
  lister:(p)=>apiCall('GET','/projets?'+new URLSearchParams(p||{}).toString(),null,false),
  soumettre:(d)=>apiCall('POST','/projets',d),
  investir:(id,mt)=>apiCall('POST','/projets/'+id+'/investir',{montant:mt})
};
const Livraisons={
  simuler:(p)=>apiCall('GET','/livraisons/simuler?'+new URLSearchParams(p||{}).toString(),null,false),
  creer:(d)=>apiCall('POST','/livraisons',d),
  suivi:(id)=>apiCall('GET','/livraisons/'+id)
};
const Admin={
  stats:()=>apiCall('GET','/admin/stats'),
  utilisateurs:(p)=>apiCall('GET','/admin/utilisateurs?'+new URLSearchParams(p||{}).toString()),
  commandes:()=>apiCall('GET','/admin/commandes'),
  changerStatut:(id,d)=>apiCall('PUT','/admin/utilisateurs/'+id+'/statut',d)
};
const Panier={
  get(){return JSON.parse(localStorage.getItem('agricam_panier')||'[]');},
  ajouter(p,q){q=q||1;const items=this.get();const i=items.findIndex(x=>x.produit._id===p._id);if(i>=0)items[i].quantite+=q;else items.push({produit:p,quantite:q});localStorage.setItem('agricam_panier',JSON.stringify(items));this.maj();},
  retirer(id){localStorage.setItem('agricam_panier',JSON.stringify(this.get().filter(i=>i.produit._id!==id)));this.maj();},
  vider(){localStorage.removeItem('agricam_panier');this.maj();},
  total(){return this.get().reduce((s,i)=>s+i.produit.prix*i.quantite,0);},
  count(){return this.get().reduce((s,i)=>s+i.quantite,0);},
  maj(){const e=document.getElementById('panier-count');if(e)e.textContent=this.count();}
};
