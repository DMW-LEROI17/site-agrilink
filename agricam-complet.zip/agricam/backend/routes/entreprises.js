const router     = require('express').Router();
const Entreprise = require('../models/Entreprise');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');
const multer = require('multer');
const path   = require('path');
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '../uploads')),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname.replace(/\s/g,'-'))
});
const upload = multer({ storage });

// GET /api/entreprises
router.get('/', async (req, res) => {
  try {
    const { type, region, page = 1, limit = 10 } = req.query;
    const filtre = { actif: true };
    if (type)   filtre.type   = type;
    if (region) filtre.region = new RegExp(region, 'i');
    const total = await Entreprise.countDocuments(filtre);
    const entreprises = await Entreprise.find(filtre).sort({ sponsorise: -1, createdAt: -1 }).skip((Number(page)-1)*Number(limit)).limit(Number(limit));
    res.json({ success: true, total, entreprises });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/entreprises/:id
router.get('/:id', async (req, res) => {
  try {
    const e = await Entreprise.findByIdAndUpdate(req.params.id, { $inc: { vues: 1 } }, { new: true });
    if (!e) return res.status(404).json({ success: false, message: 'Entreprise introuvable.' });
    res.json({ success: true, entreprise: e });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/entreprises - Créer profil entreprise
router.post('/', authMiddleware, upload.single('logo'), async (req, res) => {
  try {
    const data = { ...req.body, responsable: req.user._id };
    if (req.file) data.logo = '/uploads/' + req.file.filename;
    const entreprise = await Entreprise.create(data);
    res.status(201).json({ success: true, message: 'Profil entreprise créé ! En attente de vérification.', entreprise });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// PUT /api/entreprises/:id/valider (Admin seulement)
router.put('/:id/valider', authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const e = await Entreprise.findByIdAndUpdate(req.params.id, { verifie: true }, { new: true });
    res.json({ success: true, message: 'Entreprise validée !', entreprise: e });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
