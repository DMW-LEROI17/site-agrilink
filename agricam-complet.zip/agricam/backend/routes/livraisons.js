const router    = require('express').Router();
const Livraison = require('../models/Livraison');
const { authMiddleware } = require('../middleware/auth');

// GET /api/livraisons/simuler - Calculer frais
router.get('/simuler', (req, res) => {
  const { villeDepart, villeArrivee, poids, typeMarchandise } = req.query;
  const distances = {
    'Yaoundé-Douala': 240, 'Douala-Yaoundé': 240, 'Yaoundé-Bafoussam': 295,
    'Bafoussam-Yaoundé': 295, 'Douala-Bafoussam': 180, 'Bafoussam-Douala': 180,
    'Yaoundé-Bamenda': 370, 'Douala-Garoua': 750, 'Yaoundé-Bertoua': 350
  };
  const cle = `${villeDepart}-${villeArrivee}`;
  const distKm = distances[cle] || 300;
  const poidsKg = Number(poids) || 50;
  const tarifBase = typeMarchandise === 'Produits frais' ? 15 : typeMarchandise === 'Matériel agricole' ? 20 : 12;
  const frais = Math.round((distKm * 3 + poidsKg * tarifBase) / 100) * 100;
  const delaiHeures = distKm < 300 ? 24 : 48;
  res.json({
    success: true, villeDepart, villeArrivee, poids: poidsKg, distanceKm: distKm,
    fraisLivraison: frais, devise: 'FCFA', delaiEstime: `${delaiHeures}h`, assuranceIncluse: true
  });
});

// POST /api/livraisons - Créer suivi livraison
router.post('/', authMiddleware, async (req, res) => {
  try {
    const code = Math.random().toString(36).substr(2,6).toUpperCase();
    const livraison = await Livraison.create({ ...req.body, codeConfirmation: code });
    res.status(201).json({ success: true, livraison, codeConfirmation: code });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/livraisons/:id - Suivi GPS
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const livraison = await Livraison.findById(req.params.id).populate('commande');
    if (!livraison) return res.status(404).json({ success: false, message: 'Livraison introuvable.' });
    res.json({ success: true, livraison });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// PUT /api/livraisons/:id/position - Mise à jour GPS
router.put('/:id/position', async (req, res) => {
  try {
    const { lat, lng, statut } = req.body;
    const livraison = await Livraison.findByIdAndUpdate(req.params.id, { coordonnees: { lat, lng }, statut: statut || undefined }, { new: true });
    res.json({ success: true, livraison });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
