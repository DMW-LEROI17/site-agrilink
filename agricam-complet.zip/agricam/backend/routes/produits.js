const router  = require('express').Router();
const Produit = require('../models/Produit');
const { authMiddleware } = require('../middleware/auth');
const multer  = require('multer');
const path    = require('path');

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '../uploads')),
  filename:    (req, file, cb) => cb(null, Date.now() + '-' + file.originalname.replace(/\s/g,'-'))
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

// GET /api/produits - Liste avec filtres
router.get('/', async (req, res) => {
  try {
    const { categorie, region, minPrix, maxPrix, q, page = 1, limit = 12 } = req.query;
    const filtre = { estActif: true };
    if (categorie) filtre.categorie = categorie;
    if (region)    filtre.region    = new RegExp(region, 'i');
    if (minPrix || maxPrix) filtre.prix = {};
    if (minPrix) filtre.prix.$gte = Number(minPrix);
    if (maxPrix) filtre.prix.$lte = Number(maxPrix);
    if (q) filtre.$text = { $search: q };
    const skip   = (Number(page) - 1) * Number(limit);
    const total  = await Produit.countDocuments(filtre);
    const produits = await Produit.find(filtre).populate('vendeur','prenom nom region note verifie').sort({ createdAt: -1 }).skip(skip).limit(Number(limit));
    res.json({ success: true, total, page: Number(page), pages: Math.ceil(total / limit), produits });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/produits/:id
router.get('/:id', async (req, res) => {
  try {
    const produit = await Produit.findByIdAndUpdate(req.params.id, { $inc: { vues: 1 } }, { new: true }).populate('vendeur','prenom nom region note verifie telephone');
    if (!produit) return res.status(404).json({ success: false, message: 'Produit introuvable.' });
    res.json({ success: true, produit });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/produits - Créer produit (authentifié)
router.post('/', authMiddleware, upload.array('photos', 5), async (req, res) => {
  try {
    const { nom, description, categorie, prix, unite, quantiteDispo, qtMinCommande, region, badge, estBio } = req.body;
    const photos = req.files ? req.files.map(f => '/uploads/' + f.filename) : [];
    const produit = await Produit.create({
      nom, description, categorie, prix: Number(prix), unite,
      quantiteDispo: Number(quantiteDispo), qtMinCommande: Number(qtMinCommande || 1),
      region, badge, estBio: estBio === 'true', photos,
      vendeur: req.user._id,
      paiementsAcceptes: {
        mtnMomo:     req.body.mtnMomo     !== 'false',
        orangeMoney: req.body.orangeMoney !== 'false',
        livraison:   req.body.livraison   === 'true'
      }
    });
    res.status(201).json({ success: true, message: 'Produit publié !', produit });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// PUT /api/produits/:id - Modifier
router.put('/:id', authMiddleware, async (req, res) => {
  try {
    const produit = await Produit.findOne({ _id: req.params.id, vendeur: req.user._id });
    if (!produit) return res.status(403).json({ success: false, message: 'Non autorisé.' });
    Object.assign(produit, req.body);
    await produit.save();
    res.json({ success: true, produit });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// DELETE /api/produits/:id
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const produit = await Produit.findOne({ _id: req.params.id, vendeur: req.user._id });
    if (!produit) return res.status(403).json({ success: false, message: 'Non autorisé.' });
    produit.estActif = false;
    await produit.save();
    res.json({ success: true, message: 'Produit retiré de la vente.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
