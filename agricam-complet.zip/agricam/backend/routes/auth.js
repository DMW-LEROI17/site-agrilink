const router  = require('express').Router();
const jwt     = require('jsonwebtoken');
const User    = require('../models/User');

const genToken = (id) => jwt.sign({ id }, process.env.JWT_SECRET || 'agricam_secret', { expiresIn: '30d' });

// POST /api/auth/inscription
router.post('/inscription', async (req, res) => {
  try {
    const { prenom, nom, telephone, email, password, role, region } = req.body;
    if (!prenom || !nom || !telephone || !password || !region)
      return res.status(400).json({ success: false, message: 'Champs obligatoires manquants.' });
    const existe = await User.findOne({ telephone });
    if (existe) return res.status(409).json({ success: false, message: 'Ce numéro est déjà inscrit.' });
    const user = await User.create({ prenom, nom, telephone, email, password, role: role || 'acheteur', region });
    res.status(201).json({ success: true, message: 'Compte créé avec succès !', token: genToken(user._id), user: user.toPublic() });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/auth/connexion
router.post('/connexion', async (req, res) => {
  try {
    const { telephone, password } = req.body;
    if (!telephone || !password)
      return res.status(400).json({ success: false, message: 'Téléphone et mot de passe requis.' });
    const user = await User.findOne({ telephone });
    if (!user || !(await user.verifierPassword(password)))
      return res.status(401).json({ success: false, message: 'Identifiants incorrects.' });
    res.json({ success: true, token: genToken(user._id), user: user.toPublic() });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/auth/moi
const { authMiddleware } = require('../middleware/auth');
router.get('/moi', authMiddleware, (req, res) => {
  res.json({ success: true, user: req.user });
});

module.exports = router;
