const router = require('express').Router();
const Projet = require('../models/Projet');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');
const multer = require('multer');
const path   = require('path');
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '../uploads')),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname.replace(/\s/g,'-'))
});
const upload = multer({ storage, limits: { fileSize: 50*1024*1024 } });

// GET /api/projets
router.get('/', async (req, res) => {
  try {
    const { type, region, typeFinancement, page = 1, limit = 9 } = req.query;
    const filtre = {};
    if (type) filtre.type = type;
    if (region) filtre.region = new RegExp(region, 'i');
    if (typeFinancement) filtre.typeFinancement = typeFinancement;
    const total  = await Projet.countDocuments(filtre);
    const projets = await Projet.find(filtre).populate('porteur','prenom nom region').sort({ createdAt: -1 }).skip((Number(page)-1)*Number(limit)).limit(Number(limit));
    res.json({ success: true, total, projets });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/projets - Soumettre un projet
router.post('/', authMiddleware, upload.array('documents', 10), async (req, res) => {
  try {
    const { titre, description, type, region, budgetTotal, montantRecherche, rentabiliteEstimee, duree, typeFinancement } = req.body;
    const documents = req.files ? req.files.map(f => ({ nom: f.originalname, url: '/uploads/' + f.filename, type: f.mimetype })) : [];
    const projet = await Projet.create({
      titre, description, type, region,
      budgetTotal: Number(budgetTotal),
      montantRecherche: Number(montantRecherche),
      rentabiliteEstimee: Number(rentabiliteEstimee || 0),
      duree, typeFinancement, documents,
      porteur: req.user._id
    });
    res.status(201).json({ success: true, message: 'Projet soumis ! Les investisseurs seront notifiés.', projet });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/projets/:id/investir
router.post('/:id/investir', authMiddleware, async (req, res) => {
  try {
    const { montant } = req.body;
    const projet = await Projet.findById(req.params.id);
    if (!projet) return res.status(404).json({ success: false, message: 'Projet introuvable.' });
    projet.investisseurs.push({ investisseur: req.user._id, montant: Number(montant), date: new Date() });
    projet.montantCollecte += Number(montant);
    if (projet.montantCollecte >= projet.montantRecherche) projet.statut = 'finance';
    await projet.save();
    res.json({ success: true, message: 'Investissement enregistré avec succès !', projet });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
