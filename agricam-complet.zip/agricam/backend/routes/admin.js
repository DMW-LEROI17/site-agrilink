const router     = require('express').Router();
const User       = require('../models/User');
const Produit    = require('../models/Produit');
const Commande   = require('../models/Commande');
const Entreprise = require('../models/Entreprise');
const Projet     = require('../models/Projet');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');

router.use(authMiddleware, adminMiddleware);

// GET /api/admin/stats
router.get('/stats', async (req, res) => {
  try {
    const [users, produits, commandes, entreprises, projets, ca] = await Promise.all([
      User.countDocuments(),
      Produit.countDocuments({ estActif: true }),
      Commande.countDocuments(),
      Entreprise.countDocuments({ verifie: true }),
      Projet.countDocuments(),
      Commande.aggregate([{ $match: { paiementStatut: 'paye' } }, { $group: { _id: null, total: { $sum: '$prixTotal' }, commissions: { $sum: '$commission' } } }])
    ]);
    res.json({
      success: true,
      stats: {
        utilisateurs: users, produits, commandes, entreprisesVerifiees: entreprises, projets,
        chiffreAffaires: ca[0]?.total || 0,
        commissions: ca[0]?.commissions || 0
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/admin/utilisateurs
router.get('/utilisateurs', async (req, res) => {
  try {
    const { role, page = 1, limit = 20 } = req.query;
    const filtre = role ? { role } : {};
    const users = await User.find(filtre).select('-password').sort({ createdAt: -1 }).skip((Number(page)-1)*Number(limit)).limit(Number(limit));
    const total = await User.countDocuments(filtre);
    res.json({ success: true, total, users });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// PUT /api/admin/utilisateurs/:id/statut
router.put('/utilisateurs/:id/statut', async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, { actif: req.body.actif, verifie: req.body.verifie }, { new: true }).select('-password');
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/admin/commandes
router.get('/commandes', async (req, res) => {
  try {
    const commandes = await Commande.find().populate('acheteur','prenom nom telephone').populate('vendeur','prenom nom').populate('produit','nom').sort({ createdAt: -1 }).limit(50);
    res.json({ success: true, commandes });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
