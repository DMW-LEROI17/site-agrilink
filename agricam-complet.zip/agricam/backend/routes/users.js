const router = require('express').Router();
const User   = require('../models/User');
const { authMiddleware } = require('../middleware/auth');

router.get('/profil/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    if (!user) return res.status(404).json({ success: false, message: 'Utilisateur introuvable.' });
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.put('/profil', authMiddleware, async (req, res) => {
  try {
    const { prenom, nom, email, region, role } = req.body;
    const user = await User.findByIdAndUpdate(req.user._id, { prenom, nom, email, region, role }, { new: true }).select('-password');
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.post('/:id/noter', authMiddleware, async (req, res) => {
  try {
    const { note } = req.body;
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: 'Utilisateur introuvable.' });
    user.note = ((user.note * user.nbEvaluations) + Number(note)) / (user.nbEvaluations + 1);
    user.nbEvaluations += 1;
    await user.save();
    res.json({ success: true, message: 'Évaluation enregistrée.', note: user.note });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
