const router   = require('express').Router();
const Commande = require('../models/Commande');
const { authMiddleware } = require('../middleware/auth');

// ---- MTN MOBILE MONEY ----
router.post('/mtn-momo/initier', authMiddleware, async (req, res) => {
  try {
    const { commandeId, telephone, montant } = req.body;
    const commande = await Commande.findById(commandeId);
    if (!commande) return res.status(404).json({ success: false, message: 'Commande introuvable.' });

    // INTÉGRATION MTN MoMo API
    // En production, remplacez par l'appel réel à l'API MTN Cameroun :
    // const response = await fetch(`${process.env.MTN_MOMO_BASE_URL}/collection/v1_0/requesttopay`, {
    //   method: 'POST',
    //   headers: {
    //     'Authorization': `Bearer ${process.env.MTN_MOMO_API_KEY}`,
    //     'X-Reference-Id': uuidv4(),
    //     'X-Target-Environment': 'sandbox',
    //     'Content-Type': 'application/json',
    //     'Ocp-Apim-Subscription-Key': process.env.MTN_MOMO_SUBSCRIPTION_KEY
    //   },
    //   body: JSON.stringify({
    //     amount: montant.toString(),
    //     currency: 'XAF',
    //     externalId: commandeId,
    //     payer: { partyIdType: 'MSISDN', partyId: telephone },
    //     payerMessage: 'Paiement AgriCam commande ' + commande.reference,
    //     payeeNote: 'AgriCam Marketplace'
    //   })
    // });

    // SIMULATION pour développement/démo :
    const refPaiement = 'MTN-' + Date.now();
    commande.paiementRef = refPaiement;
    commande.paiementStatut = 'en_attente';
    await commande.save();

    res.json({
      success: true,
      message: `Demande de paiement MTN MoMo envoyée au +237${telephone}. Confirmez sur votre téléphone.`,
      reference: refPaiement,
      instruction: `Vous allez recevoir une notification MTN MoMo. Entrez votre PIN pour valider ${montant.toLocaleString('fr-FR')} FCFA.`
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Callback MTN MoMo (webhook appelé par MTN après paiement)
router.post('/mtn-momo/callback', async (req, res) => {
  try {
    const { externalId, status } = req.body;
    if (status === 'SUCCESSFUL') {
      await Commande.findByIdAndUpdate(externalId, { paiementStatut: 'paye', statut: 'confirmee' });
    }
    res.status(200).send('OK');
  } catch (err) {
    res.status(500).send('Erreur callback');
  }
});

// ---- ORANGE MONEY ----
router.post('/orange-money/initier', authMiddleware, async (req, res) => {
  try {
    const { commandeId, telephone, montant } = req.body;
    const commande = await Commande.findById(commandeId);
    if (!commande) return res.status(404).json({ success: false, message: 'Commande introuvable.' });

    // INTÉGRATION Orange Money API Cameroun
    // const tokenResp = await fetch(`${process.env.ORANGE_MONEY_BASE_URL}/token`, {
    //   method: 'POST',
    //   headers: { 'Authorization': 'Basic ' + Buffer.from(`${process.env.ORANGE_MONEY_CLIENT_ID}:${process.env.ORANGE_MONEY_CLIENT_SECRET}`).toString('base64') }
    // });
    // const { access_token } = await tokenResp.json();
    // const payResp = await fetch(`${process.env.ORANGE_MONEY_BASE_URL}/webpayment`, {
    //   method: 'POST', headers: { 'Authorization': `Bearer ${access_token}`, 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ merchant_key: process.env.ORANGE_MONEY_MERCHANT_KEY, currency: 'XAF', order_id: commande.reference, amount: montant, return_url: '...', cancel_url: '...', notif_url: '...' })
    // });

    const refPaiement = 'OM-' + Date.now();
    commande.paiementRef = refPaiement;
    await commande.save();

    res.json({
      success: true,
      message: `Demande Orange Money envoyée au +237${telephone}. Confirmez sur votre téléphone.`,
      reference: refPaiement,
      instruction: `Composez #144*82# ou confirmez via l'app Orange Money pour valider ${montant.toLocaleString('fr-FR')} FCFA.`
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Vérifier statut paiement
router.get('/statut/:commandeId', authMiddleware, async (req, res) => {
  try {
    const commande = await Commande.findById(req.params.commandeId).select('paiementStatut paiementRef reference modePaiement');
    if (!commande) return res.status(404).json({ success: false, message: 'Commande introuvable.' });
    res.json({ success: true, paiementStatut: commande.paiementStatut, paiementRef: commande.paiementRef });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
