const router   = require('express').Router();
const Commande = require('../models/Commande');
const Produit  = require('../models/Produit');
const { authMiddleware } = require('../middleware/auth');

// POST /api/commandes - Passer une commande
router.post('/', authMiddleware, async (req, res) => {
  try {
    const { produitId, quantite, modePaiement, adresseLivraison, fraisLivraison } = req.body;
    const produit = await Produit.findById(produitId).populate('vendeur');
    if (!produit || !produit.estActif)
      return res.status(404).json({ success: false, message: 'Produit introuvable.' });
    if (produit.quantiteDispo < quantite)
      return res.status(400).json({ success: false, message: 'Stock insuffisant.' });
    const prixTotal = produit.prix * quantite + (fraisLivraison || 0);
    const code = Math.random().toString(36).substr(2,6).toUpperCase();
    const commande = await Commande.create({
      acheteur: req.user._id,
      vendeur:  produit.vendeur._id,
      produit:  produitId,
      quantite, prixUnitaire: produit.prix, prixTotal,
      modePaiement, adresseLivraison,
      fraisLivraison: fraisLivraison || 0,
      codeConfirmation: code
    });
    produit.quantiteDispo -= quantite;
    await produit.save();
    res.status(201).json({ success: true, message: 'Commande créée !', commande, codeConfirmation: code });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/commandes/mes-commandes
router.get('/mes-commandes', authMiddleware, async (req, res) => {
  try {
    const commandes = await Commande.find({ acheteur: req.user._id }).populate('produit','nom photos prix unite').populate('vendeur','prenom nom telephone').sort({ createdAt: -1 });
    res.json({ success: true, commandes });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/commandes/mes-ventes
router.get('/mes-ventes', authMiddleware, async (req, res) => {
  try {
    const commandes = await Commande.find({ vendeur: req.user._id }).populate('produit','nom photos').populate('acheteur','prenom nom telephone').sort({ createdAt: -1 });
    res.json({ success: true, commandes });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// PUT /api/commandes/:id/statut
router.put('/:id/statut', authMiddleware, async (req, res) => {
  try {
    const { statut, codeConfirmation } = req.body;
    const commande = await Commande.findById(req.params.id);
    if (!commande) return res.status(404).json({ success: false, message: 'Commande introuvable.' });
    if (statut === 'livree' && commande.codeConfirmation !== codeConfirmation)
      return res.status(400).json({ success: false, message: 'Code de confirmation incorrect.' });
    commande.statut = statut;
    if (statut === 'livree') { commande.paiementStatut = 'paye'; commande.dateLivraison = new Date(); }
    await commande.save();
    res.json({ success: true, commande });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
