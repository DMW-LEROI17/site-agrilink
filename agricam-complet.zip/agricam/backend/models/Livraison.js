const mongoose = require('mongoose');

const livraisonSchema = new mongoose.Schema({
  commande:      { type: mongoose.Schema.Types.ObjectId, ref: 'Commande', required: true },
  transporteur:  { nom: String, telephone: String, vehicule: String },
  villeDepart:   { type: String, required: true },
  villeArrivee:  { type: String, required: true },
  frais:         { type: Number, required: true },
  statut: {
    type: String,
    enum: ['en_attente','prise_en_charge','en_route','arrive','livre'],
    default: 'en_attente'
  },
  coordonnees:   { lat: Number, lng: Number },
  dateEstimee:   { type: Date },
  dateLivraison: { type: Date },
  codeConfirmation: { type: String }
}, { timestamps: true });

module.exports = mongoose.model('Livraison', livraisonSchema);
