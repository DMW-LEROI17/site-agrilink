const mongoose = require('mongoose');

const entrepriseSchema = new mongoose.Schema({
  nom:          { type: String, required: true },
  description:  { type: String, default: '' },
  type: {
    type: String,
    enum: ['semences','engrais','pesticides','materiel','irrigation','veterinaire','numerique','autre'],
    required: true
  },
  logo:         { type: String, default: '' },
  responsable:  { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  telephone:    { type: String, required: true },
  email:        { type: String },
  adresse:      { type: String },
  region:       { type: String },
  verifie:      { type: Boolean, default: false },
  sponsorise:   { type: Boolean, default: false },
  produits:     [{ nom: String, description: String, prix: Number, unite: String, photo: String }],
  promotions:   [{ titre: String, description: String, reduction: Number, dateExpiration: Date }],
  vues:         { type: Number, default: 0 },
  actif:        { type: Boolean, default: true }
}, { timestamps: true });

module.exports = mongoose.model('Entreprise', entrepriseSchema);
