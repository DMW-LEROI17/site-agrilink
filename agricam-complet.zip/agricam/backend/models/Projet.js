const mongoose = require('mongoose');

const projetSchema = new mongoose.Schema({
  titre:        { type: String, required: true },
  description:  { type: String, required: true },
  type:         { type: String, enum: ['maraichage','elevage','plantation','transformation','pisciculture','apiculture','autre'], required: true },
  region:       { type: String, required: true },
  porteur:      { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  budgetTotal:  { type: Number, required: true },
  montantRecherche: { type: Number, required: true },
  montantCollecte:  { type: Number, default: 0 },
  rentabiliteEstimee: { type: Number, default: 0 },
  duree:        { type: String, default: '2 ans' },
  typeFinancement: { type: String, enum: ['investisseur','crowdfunding','pret','subvention'], default: 'investisseur' },
  statut:       { type: String, enum: ['en_attente','valide','finance','cloture'], default: 'en_attente' },
  documents:    [{ nom: String, url: String, type: String }],
  investisseurs:[{ investisseur: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, montant: Number, date: Date }],
  vues:         { type: Number, default: 0 }
}, { timestamps: true });

module.exports = mongoose.model('Projet', projetSchema);
