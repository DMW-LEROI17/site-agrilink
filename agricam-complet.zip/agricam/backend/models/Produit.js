const mongoose = require('mongoose');

const produitSchema = new mongoose.Schema({
  nom:           { type: String, required: true, trim: true },
  description:   { type: String, default: '' },
  categorie: {
    type: String,
    enum: ['legumes','fruits','cereales','elevage','epices','legumineuses','poissons','fleurs','autres'],
    required: true
  },
  photos:        [{ type: String }],
  prix:          { type: Number, required: true, min: 0 },
  unite:         { type: String, required: true, enum: ['kg','litre','sac25','sac50','cageot','tete','piece','botte'] },
  quantiteDispo: { type: Number, required: true, min: 0 },
  qtMinCommande: { type: Number, default: 1 },
  region:        { type: String, required: true },
  vendeur:       { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  paiementsAcceptes: {
    mtnMomo:       { type: Boolean, default: true },
    orangeMoney:   { type: Boolean, default: true },
    livraison:     { type: Boolean, default: false }
  },
  badge:         { type: String, default: 'Frais' },
  estBio:        { type: Boolean, default: false },
  estActif:      { type: Boolean, default: true },
  note:          { type: Number, default: 0, min: 0, max: 5 },
  nbEvaluations: { type: Number, default: 0 },
  vues:          { type: Number, default: 0 }
}, { timestamps: true });

produitSchema.index({ nom: 'text', description: 'text' });
produitSchema.index({ categorie: 1, region: 1 });

module.exports = mongoose.model('Produit', produitSchema);
