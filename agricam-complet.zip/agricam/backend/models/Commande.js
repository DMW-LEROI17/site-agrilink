const mongoose = require('mongoose');

const commandeSchema = new mongoose.Schema({
  reference:   { type: String, unique: true },
  acheteur:    { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  vendeur:     { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  produit:     { type: mongoose.Schema.Types.ObjectId, ref: 'Produit', required: true },
  quantite:    { type: Number, required: true, min: 1 },
  prixUnitaire:{ type: Number, required: true },
  prixTotal:   { type: Number, required: true },
  commission:  { type: Number, default: 0 }, // 2% prélevé par AgriCam
  statut: {
    type: String,
    enum: ['en_attente','confirmee','en_preparation','en_livraison','livree','annulee'],
    default: 'en_attente'
  },
  modePaiement: {
    type: String,
    enum: ['mtn_momo','orange_money','livraison'],
    required: true
  },
  paiementStatut: {
    type: String,
    enum: ['en_attente','paye','rembourse'],
    default: 'en_attente'
  },
  paiementRef:  { type: String, default: '' },
  adresseLivraison: { type: String, required: true },
  fraisLivraison:   { type: Number, default: 0 },
  codeConfirmation: { type: String, default: '' },
  noteAcheteur: { type: Number, min: 1, max: 5 },
  noteVendeur:  { type: Number, min: 1, max: 5 }
}, { timestamps: true });

commandeSchema.pre('save', async function(next) {
  if (!this.reference) {
    this.reference = 'CMD-' + Date.now() + '-' + Math.random().toString(36).substr(2,5).toUpperCase();
  }
  this.commission = this.prixTotal * 0.02;
  next();
});

module.exports = mongoose.model('Commande', commandeSchema);
