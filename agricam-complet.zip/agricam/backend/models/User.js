const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

const userSchema = new mongoose.Schema({
  prenom:    { type: String, required: true, trim: true },
  nom:       { type: String, required: true, trim: true },
  telephone: { type: String, required: true, unique: true },
  email:     { type: String, unique: true, sparse: true, lowercase: true },
  password:  { type: String, required: true, minlength: 8 },
  role: {
    type: String,
    enum: ['agriculteur','acheteur','entreprise','porteur_projet','investisseur','admin'],
    default: 'acheteur'
  },
  region:    { type: String, required: true },
  verifie:   { type: Boolean, default: false },
  avatar:    { type: String, default: '' },
  note:      { type: Number, default: 0, min: 0, max: 5 },
  nbEvaluations: { type: Number, default: 0 },
  actif:     { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now }
}, { timestamps: true });

userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

userSchema.methods.verifierPassword = async function(password) {
  return bcrypt.compare(password, this.password);
};

userSchema.methods.toPublic = function() {
  const obj = this.toObject();
  delete obj.password;
  return obj;
};

module.exports = mongoose.model('User', userSchema);
