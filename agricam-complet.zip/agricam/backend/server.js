// ============================================================
//  AGRICAM - SERVEUR PRINCIPAL
//  Node.js + Express + MongoDB
// ============================================================
require('dotenv').config();
const express    = require('express');
const mongoose   = require('mongoose');
const cors       = require('cors');
const morgan     = require('morgan');
const path       = require('path');

const app = express();

// ---- MIDDLEWARE ----
app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ---- CONNEXION MONGODB ----
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/agricam')
  .then(() => console.log('✅ MongoDB connecté avec succès'))
  .catch(err => console.error('❌ Erreur MongoDB :', err.message));

// ---- ROUTES API ----
app.use('/api/auth',        require('./routes/auth'));
app.use('/api/users',       require('./routes/users'));
app.use('/api/produits',    require('./routes/produits'));
app.use('/api/commandes',   require('./routes/commandes'));
app.use('/api/entreprises', require('./routes/entreprises'));
app.use('/api/projets',     require('./routes/projets'));
app.use('/api/paiements',   require('./routes/paiements'));
app.use('/api/livraisons',  require('./routes/livraisons'));
app.use('/api/admin',       require('./routes/admin'));

// ---- ROUTE RACINE ----
app.get('/', (req, res) => {
  res.json({
    message: '🌱 AgriCam API - Marketplace Agricole Camerounais',
    version: '1.0.0',
    status: 'En ligne',
    endpoints: {
      auth:        '/api/auth',
      produits:    '/api/produits',
      commandes:   '/api/commandes',
      entreprises: '/api/entreprises',
      projets:     '/api/projets',
      paiements:   '/api/paiements',
      livraisons:  '/api/livraisons',
      admin:       '/api/admin'
    }
  });
});

// ---- GESTION ERREURS GLOBALE ----
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Erreur serveur interne'
  });
});

// ---- DÉMARRAGE ----
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n🚀 AgriCam API démarrée sur http://localhost:${PORT}`);
  console.log(`📱 Mobile Money: MTN MoMo + Orange Money configurés`);
  console.log(`🗄️  Base de données: MongoDB\n`);
});

module.exports = app;
