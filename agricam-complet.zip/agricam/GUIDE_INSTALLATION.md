# 🌱 AGRICAM — GUIDE D'INSTALLATION COMPLET
## Pour non-techniciens — Suivez exactement ces étapes

---

## ÉTAPE 1 — Installer les logiciels nécessaires (1 seule fois)

### 1A. Installer Node.js
1. Allez sur : **https://nodejs.org**
2. Cliquez sur le bouton vert **"LTS" (recommandé)**
3. Téléchargez et installez (cliquez "Suivant" jusqu'à la fin)
4. ✅ Vérification : ouvrez un terminal et tapez `node -v` → vous devez voir un numéro

### 1B. Installer MongoDB (base de données)
- **Option A — MongoDB Atlas (GRATUIT, recommandé, pas besoin d'installer)** :
  1. Allez sur **https://www.mongodb.com/atlas**
  2. Créez un compte gratuit
  3. Créez un cluster gratuit (M0 Free)
  4. Cliquez "Connect" → obtenez votre URL de connexion
  5. Remplacez dans le fichier `.env` : `MONGODB_URI=votre_url_atlas`

- **Option B — MongoDB local** :
  1. Allez sur **https://www.mongodb.com/try/download/community**
  2. Téléchargez et installez MongoDB Community Server
  3. L'URL reste : `mongodb://localhost:27017/agricam`

---

## ÉTAPE 2 — Configurer le projet

1. Ouvrez le dossier `agricam/backend`
2. Trouvez le fichier `.env.example`
3. **Dupliquez-le** et renommez la copie `.env` (sans "example")
4. Ouvrez `.env` avec le Bloc-notes et modifiez :
   ```
   MONGODB_URI=votre_url_mongodb
   JWT_SECRET=mettez_nimporte_quelle_longue_phrase_secrete_ici
   PORT=3000
   ```
5. Sauvegardez

---

## ÉTAPE 3 — Démarrer le serveur backend

### Sur Windows :
1. Ouvrez le dossier `agricam/backend`
2. **Cliquez dans la barre d'adresse** de l'explorateur de fichiers
3. Tapez `cmd` et appuyez sur Entrée
4. Dans la fenêtre noire qui s'ouvre, tapez :
   ```
   npm install
   ```
   Attendez (2-3 minutes)
5. Ensuite tapez :
   ```
   npm start
   ```
6. Vous devez voir :
   ```
   ✅ MongoDB connecté avec succès
   🚀 AgriCam API démarrée sur http://localhost:3000
   ```

### Sur Mac/Linux :
1. Ouvrez le Terminal
2. Tapez : `cd chemin/vers/agricam/backend`
3. Tapez : `npm install`
4. Tapez : `npm start`

---

## ÉTAPE 4 — Ouvrir le site web

1. Allez dans le dossier `agricam/frontend`
2. Double-cliquez sur `index.html`
3. Le site s'ouvre dans votre navigateur
4. ✅ Tout est connecté au backend !

---

## ÉTAPE 5 — Tester que tout fonctionne

Ouvrez votre navigateur et allez sur :
- **http://localhost:3000** → doit afficher l'API AgriCam
- **http://localhost:3000/api/produits** → doit afficher `{"success":true,"produits":[]}`

---

## ACCÈS ANDROID (Application mobile)

Pour convertir en APK Android :

1. Installez : **https://nodejs.org** (déjà fait)
2. Installez **Android Studio** : https://developer.android.com/studio
3. Dans le terminal, dans le dossier `agricam` :
   ```
   npm install -g @capacitor/cli
   npx cap init AgriCam com.agricam.app
   npx cap add android
   npx cap sync
   npx cap open android
   ```
4. Dans Android Studio : cliquez **Build → Generate Signed APK**
5. Votre APK est prêt à installer sur Android !

---

## PAIEMENTS MOBILE MONEY (Production)

### MTN MoMo :
1. Allez sur : **https://momodeveloper.mtn.com**
2. Créez un compte développeur
3. Créez une application → obtenez votre API Key
4. Renseignez dans `.env` : `MTN_MOMO_API_KEY=...`

### Orange Money :
1. Allez sur : **https://developer.orange.com**
2. Créez un compte → inscrivez-vous à "Orange Money"
3. Obtenez Client ID et Secret
4. Renseignez dans `.env` : `ORANGE_MONEY_CLIENT_ID=...`

---

## DÉPLOIEMENT EN LIGNE (rendre accessible sur internet)

### Option gratuite — Railway.app :
1. Allez sur **https://railway.app**
2. Connectez votre GitHub
3. "New Project" → "Deploy from GitHub"
4. Ajoutez les variables d'environnement de votre `.env`
5. Votre site est en ligne avec une URL publique !

### Option professionnelle :
- **DigitalOcean** : ~6$/mois
- **AWS Africa (Cape Town)** : meilleure latence pour le Cameroun

---

## EN CAS DE PROBLÈME

| Erreur | Solution |
|--------|----------|
| `npm: command not found` | Réinstallez Node.js depuis nodejs.org |
| `MongoDB connection error` | Vérifiez votre URL dans `.env` |
| `Port 3000 already in use` | Changez `PORT=3001` dans `.env` |
| Page blanche dans le navigateur | Vérifiez que `npm start` est bien lancé |

---

## CONTACT DÉVELOPPEUR

Pour une intégration professionnelle complète (déploiement, MTN MoMo réel, Android Play Store), contactez un développeur Node.js Cameroun ou postez sur :
- **Upwork.com** (cherchez "Node.js Cameroon developer")
- **CamDev WhatsApp Groups**

