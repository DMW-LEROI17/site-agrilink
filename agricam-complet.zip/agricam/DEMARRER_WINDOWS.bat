@echo off
echo ==========================================
echo   AGRICAM - Demarrage du serveur
echo ==========================================
echo.
cd /d "%~dp0backend"
echo Installation des dependances...
call npm install
echo.
echo Demarrage du serveur AgriCam...
echo Le serveur sera accessible sur http://localhost:3000
echo.
echo Pour ouvrir le site : double-cliquez sur frontend/index.html
echo.
npm start
pause
