#!/bin/bash
echo "=========================================="
echo "  AGRICAM - Demarrage du serveur"
echo "=========================================="
cd "$(dirname "$0")/backend"
echo "Installation des dependances..."
npm install
echo ""
echo "Demarrage du serveur AgriCam..."
echo "Accessible sur http://localhost:3000"
echo "Ouvrez frontend/index.html dans votre navigateur"
echo ""
npm start
